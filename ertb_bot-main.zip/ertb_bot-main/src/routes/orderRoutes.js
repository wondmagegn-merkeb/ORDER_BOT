const express = require('express');
const { updateOrder } = require('../controllers/orderController');

const router = express.Router();



router.post('/edit/:id', updateOrder);


module.exports = router
