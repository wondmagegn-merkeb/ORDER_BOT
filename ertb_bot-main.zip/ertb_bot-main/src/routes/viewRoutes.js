const express = require('express');
const router = express.Router();
const {
    showDashboard,
    showOrders,
    showItems,
    showUsers,
    showLogin,
    adminLogin,
    adminLogout,
    addItem,
    editItem,
    deleteItem,
    adminList,
    deleteAdmin,
    adminEdit,
    showDetailOrder,
    adminAdd
    
} = require('../controllers/viewController');

// ===================== Admin Panel Views =====================
router.get('/dashboard', showDashboard);
router.get('/orders', showOrders);
router.get('/items', showItems);
router.get('/users', showUsers);
router.get('/orders/:id', showDetailOrder);

// ===================== Authentication =====================
router.get('/login', showLogin);
router.post('/login', adminLogin);
router.get('/logout', adminLogout);

// ===================== Admin Management =====================
router.get('/admins', adminList);
router.get('/create', adminAdd);
router.get('/edit/:id', adminEdit);
router.get('/delete/:id', deleteAdmin);

// ===================== Item Management =====================
router.get('/addItem', addItem);                  // Show form to add item
router.get('/updateItem/:id', editItem);          // Show form to edit item
router.get('/deleteItem/:id', deleteItem);        // Delete item by ID

// ===================== Item Management =====================
         // Show form to edit item
       
module.exports = router;
