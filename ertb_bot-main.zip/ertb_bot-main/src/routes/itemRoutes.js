const express = require('express');

const { createItem, getItems, getItemById, updateItem, deleteItem } = require('../controllers/itemController');
const upload = require("../../middleware/uploadMiddleware");
const router = express.Router();


// Routes
router.post('/', upload.single('image'), createItem);
router.get('/', getItems);
router.get('/:id', getItemById);
router.post('/:id/edit', upload.single('image'), updateItem);
router.delete('/:id', deleteItem);

module.exports = router;
