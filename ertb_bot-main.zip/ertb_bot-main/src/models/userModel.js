const { DataTypes } = require('sequelize');
const { sequelize } = require('../../config/db');  // ✅ Correct import

const User = sequelize.define('User', {
    telegramId: {
        type: DataTypes.STRING,
        primaryKey: true,
       
    },
   
    username: {
        type: DataTypes.STRING,
        allowNull: true,  // Allow null, since not all users may have a username
        unique: true
    },
   
}, {
    timestamps: true,
    tableName: 'users'
});

// Associations


module.exports = User;
