// src/models/subscriptionModel.js
const { DataTypes } = require('sequelize');
const { sequelize } = require('../../config/db'); // Adjust path as needed

const Subscription = sequelize.define('Subscription', {
  endpoint: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  expirationTime: {
    type: DataTypes.DATE,
    allowNull: true
  },
  keys: {
    type: DataTypes.JSON,
    allowNull: false
  }
});

module.exports = {
  Subscription
};
