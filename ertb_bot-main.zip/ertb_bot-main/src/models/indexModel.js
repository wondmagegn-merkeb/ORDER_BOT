const Sequelize = require('sequelize');
const { sequelize } = require('../../config/db');

const User = require('./userModel');
const Item = require('./itemModel');
const Order = require('./orderModel');

// Setup associations with correct keys
Order.belongsTo(User, { foreignKey: 'telegramId', targetKey: 'telegramId' });
Order.belongsTo(Item, { foreignKey: 'itemId', targetKey: 'itemId' });

User.hasMany(Order, { foreignKey: 'telegramId', sourceKey: 'telegramId' });
Item.hasMany(Order, { foreignKey: 'itemId', sourceKey: 'itemId' });

module.exports = {
  sequelize,
  User,
  Item,
  Order
};
