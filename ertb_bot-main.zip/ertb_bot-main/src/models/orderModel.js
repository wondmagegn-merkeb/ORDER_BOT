const { DataTypes } = require('sequelize');
const { sequelize } = require('../../config/db'); // ✅ Ensure correct import

// Define Order model
const Order = sequelize.define('Order', {
    orderId: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    telegramId: {
        type: DataTypes.STRING,
        allowNull: false
    },
    itemId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    status: {
        type: DataTypes.STRING,
        defaultValue: 'Pending',  // Default order status
        allowNull: false
    },
    fullName: {
        type: DataTypes.STRING,
        allowNull: true
    },
    location: {
        type: DataTypes.STRING,
        allowNull: true
    },
    phone1: {
        type: DataTypes.STRING,
        allowNull: true
    },
    phone2: {
        type: DataTypes.STRING,
        allowNull: true
    },
    special: {
        type: DataTypes.STRING,
        allowNull: true
    },
    quantity: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    totalPrice: {
        type: DataTypes.FLOAT,
        allowNull: false
    },
    newTotalPrice :{
        type: DataTypes.FLOAT,
        allowNull: false
    }
}, {
    timestamps: true, // ✅ CreatedAt and UpdatedAt timestamps
    tableName: 'orders'
});

// Define associations (Ensure User and Item models exist)


// Sync model with database (create table if not exists)
sequelize.sync()
    .then(() => console.log('✅ Order table synced successfully.'))
    .catch(err => console.error('❌ Error syncing Order table:', err));

module.exports = Order;
