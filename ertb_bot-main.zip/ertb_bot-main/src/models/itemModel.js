const { DataTypes } = require('sequelize');
const { sequelize } = require('../../config/db'); // ✅ Correct import

const Item = sequelize.define('Item', {
    itemId: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    description: {
        type: DataTypes.STRING,
        allowNull: true
    },
    price: {
        type: DataTypes.FLOAT,
        allowNull: false
    },
    availability: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 1  // 1 for available, 0 for not available
    },
    imageUrl: {
        type: DataTypes.STRING,
        allowNull: true
    },
    cloudinaryPublicId:  {
        type: DataTypes.STRING,
        allowNull: true
    }
}, {
    timestamps: true,
    tableName: 'items'
});

// Associations (if any)

module.exports = Item;
