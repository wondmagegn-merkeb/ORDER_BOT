const Admin = require('../models/adminModel');
const { Order, Item, User } = require('../models/indexModel');

// Show Admin Dashboard
exports.showDashboard = async (req, res) => {
    try {
        const totalItems = await Item.count();
        const totalAdmins = await Admin.count();
        const totalUsers = await User.count();

        const pendingOrders = await Order.count({ where: { status: 'Pending' } });
        const finishedOrders = await Order.count({ where: { status: 'Finished' } });
        const arrivedOrders = await Order.count({ where: { status: 'Arrived' } });

        const orders = await Order.findAll({
            include: [{ model: Item, attributes: ['name'] }],
            limit: 10,
            offset: 0
        });

        const content = "Welcome to the Admin Dashboard! Here is the overview of your platform.";
        const message = content || null;

        res.render('admin/dashboard', {
            title: "Admin Dashboard",
            content,
            totalItems,
            totalAdmins,
            totalUsers,
            pendingOrders,
            finishedOrders,
            arrivedOrders,
            message
        });
    } catch (error) {
        res.status(500).render('error', { message: 'Error fetching dashboard data' });
    }
};

// Add Item
exports.addItem = async (req, res) => {
    try {
        // Logic to add item (e.g., using req.body)
      

        res.render('admin/addItem', {title:"Add Item",message:""});
    } catch (error) {
        res.status(500).render('error', { message: 'Error adding item' });
    }
};

// Edit Item
exports.editItem = async (req, res) => {
    try {
        const item = await Item.findByPk(req.params.id);
        res.render('admin/updateItem', { title: "Edit Item", item, id: req.params.id,message:"" });
    } catch (err) {
        res.status(500).render('error', { message: 'Error fetching item for editing' });
    }
};



// Delete Item
exports.deleteItem = async (req, res) => {
    try {
        const { id } = req.params;
        const item = await Item.findByPk(id);

        if (!item) {
            return res.status(404).render('error', { message: 'Item not found' });
        }

        await item.destroy();
        const items = await Item.findAll();
        res.render('admin/items', {
            title: "Manage Items",
            items,
            message: "Item deleted successfully!"
        });
    } catch (error) {
        res.status(400).render('error', { message: error.message });
    }
};

// Show Items page
exports.showItems = async (req, res) => {
    try {
        const items = await Item.findAll();
        res.render('admin/items', { title: "Manage Items", items ,message:""});
    } catch (error) {
        res.status(500).render('error', { message: 'Error loading items' });
    }
};

// Show Orders page
exports.showOrders = async (req, res) => {
    try {
        const orders = await Order.findAll();
        res.render('admin/orders', { title: "Manage Orders", orders ,message:""});
    } catch (error) {
        res.status(500).render('error', { message: 'Error loading orders' });
    }
};

// Show Order Details page
exports.showDetailOrder = async (req, res) => {
    try {
        const { id } = req.params;
        const order = await Order.findByPk(id, {
            include: [
                { model: User, attributes: ['username'] },
                { model: Item, attributes: ['name', 'price', 'description', 'imageUrl'] }
            ]
        });

        if (!order) {
            return res.status(404).render('error', { message: 'Order not found' });
        }

        res.render('admin/orderDetail', { title: "Order Detail", order,message:"" });
    } catch (error) {
        res.status(500).render('error', { message: 'Error loading order details' });
    }
};


// Show Users page
exports.showUsers = async (req, res) => {
    try {
        const users = await User.findAll();
        res.render('admin/users', { title: "Manage Users", users,message:"" });
    } catch (error) {
        res.status(500).render('error', { message: 'Error loading users' });
    }
};




// Admin login page
exports.showLogin = (req, res) => {
    try {
        res.render('admin/login', { title: "Admin Login", error: null });
    } catch (error) {
        res.status(500).render('error', { message: 'Error loading login page' });
    }
};
exports.adminList = async (req, res) => {
    try {
        // Fetch all admins from the database
        const admins = await Admin.findAll();

        // Render the listAdmin view with fetched admins data
        res.render('admin/listAdmin', { 
            title: "Admin List", 
            admins,
            message:""
        });
    } catch (error) {
        // Handle errors
        res.status(500).render('error', { message: 'Error loading admin list' });
    }
};


// Show Add Admin Page
exports.adminAdd = async (req, res) => {
    try {
        res.render('admin/addAdmin', { title: "Add Admin", error: null,message:"" });
    } catch (error) {
        res.status(500).render('error', { message: 'Error loading the admin add page' });
    }
};



// Show Edit Admin Page
exports.adminEdit = async (req, res) => {
    try {
        const admin = await Admin.findByPk(req.params.id);
        if (!admin) {
            return res.status(404).render('error', { message: 'Admin not found' });
        }

        res.render('admin/editAdmin', { title: "Edit Admin", admin ,message:""});
    } catch (error) {
        res.status(500).render('error', { message: 'Error loading admin edit page' });
    }
};




// Delete Admin
exports.deleteAdmin = async (req, res) => {
    const { id } = req.params;

    try {
        const admin = await Admin.findByPk(id);
        if (!admin) {
            return res.status(404).render('error', { message: 'Admin not found' });
        }

        // Destroy admin
        await admin.destroy();
        res.redirect('/admin/listAdmin',{title:"Admin List",message:"Admin deleted successfully!"});
    } catch (error) {
        res.status(500).render('error', { message: 'Error deleting admin' });
    }
};

// Admin List
exports.adminList = async (req, res) => {
    try {
        const admins = await Admin.findAll();
       
        res.render('admin/listAdmin', { title: "Admin List", admins, message:"" });
    } catch (error) {
        res.status(500).render('error', { message: 'Error fetching admin list' });
    }
};



// Admin login logic
exports.adminLogin = async (req, res) => {
    const { email, password } = req.body;

    try {
        const admin = await Admin.findOne({ where: { email } });

        if (!admin || admin.password !== password) {
            return res.render('admin/login', { title: "Admin Login", error: "Invalid credentials" });
        }

        req.session.adminId = admin.adminId;
        res.redirect('/admin/dashboard');
    } catch (error) {
        res.status(500).render('error', { message: 'Login error' });
    }
};

// Admin logout
exports.adminLogout = (req, res) => {
    req.session.destroy(() => {
        res.render('admin/login', { layout: false });
    });
};
