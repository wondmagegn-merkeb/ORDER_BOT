const Admin = require('../models/adminModel');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Create Admin
const createAdmin = async (req, res) => {
    try {
        const { username, email, password } = req.body;

        if (!email || !password || !username) {
            return res.render('admin/addAdmin', {
                title: 'Missing Fields',
                message: 'Username, email, and password are required.'
            });
        }
        const existingAdmin = await Admin.findOne({ where: { email } });
        if (existingAdmin) {
            return res.render('admin/addAdmin', { title: "Add Admin", message: "Admin already exists with this email" });
        }
        const hashedPassword = await bcrypt.hash(password, 10);

        await Admin.create({
            username,
            email,
            password: hashedPassword
        });

        const admins = await Admin.findAll();
        res.render('admin/listAdmin', { title: "Admin List", admins,message:'' });

    } catch (error) {
        res.status(500).render('error', {
            title: 'Create Admin Error',
            message: 'Failed to create admin.',
            error: error.message
        });
    }
};

// Get all admins
const getAdmins = async (req, res) => {
    try {
        const admins = await Admin.findAll();
        res.status(200).json({ success: true, admins });
    } catch (error) {
        res.status(500).render('error', {
            title: 'Fetch Admins Error',
            message: 'Unable to fetch admins.',
            error: error.message
        });
    }
};

// Get single admin by ID
const getAdminById = async (req, res) => {
    try {
        const { id } = req.params;
        const admin = await Admin.findByPk(id);

        if (!admin) {
            return res.status(404).render('error', {
                title: 'Admin Not Found',
                message: `No admin found with ID ${id}`
            });
        }

        res.status(200).json({ success: true, admin });

    } catch (error) {
        res.status(500).render('error', {
            title: 'Fetch Admin Error',
            message: 'Unable to fetch the admin.',
            error: error.message
        });
    }
};

// Update Admin
const updateAdmin = async (req, res) => {
    try {
        const { id } = req.params;
        const { username, email, password } = req.body;

        const admin = await Admin.findByPk(id);

        if (!admin) {
            return res.status(404).render('error', { message: 'Admin not found' });
        }

        let updateData = { username, email };

        if (password) {
            updateData.password = await bcrypt.hash(password, 10);
        }

        await admin.update(updateData);

        const admins = await Admin.findAll();
        res.render('admin/listAdmin', { title: "Admin List", admins ,message:"Admin updated successfully!"});
       
    } catch (error) {
        res.status(500).render('error', {
            title: 'Update Admin Error',
            message: 'Failed to update admin.',
            error: error.message
        });
    }
};

// Delete Admin
const deleteAdmin = async (req, res) => {
    try {
        const { id } = req.params;
        const admin = await Admin.findByPk(id);

        if (!admin) {
            return res.status(404).render('error', {
                title: 'Admin Not Found',
                message: `Cannot delete: No admin found with ID ${id}`
            });
        }

        await admin.destroy();
        res.status(200).json({ success: true, message: 'Admin deleted successfully' });

    } catch (error) {
        res.status(500).render('error', {
            title: 'Delete Admin Error',
            message: 'Failed to delete admin.',
            error: error.message
        });
    }
};

// Admin Login
const loginAdmin = async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).render('error', {
                title: 'Login Error',
                message: 'Email and password are required.'
            });
        }
console.log('login')
        const admin = await Admin.findOne({ where: { email } });
console.log(admin)
        if (!admin) {
            return res.status(404).render('error', {
                title: 'Admin Not Found',
                message: 'No admin found with the provided email.'
            });
        }
console.log('admin')
        const isPasswordValid = await bcrypt.compare(password, admin.password);
        if (!isPasswordValid) {
            return res.status(401).render('error', {
                title: 'Invalid Credentials',
                message: 'The password you entered is incorrect.'
            });
        }

        const token = jwt.sign({ id: admin.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        req.session.token = token;

        res.status(200).json({
            success: true,
            message: 'Login successful',
            token
        });

    } catch (error) {
        res.status(500).render('error', {
            title: 'Login Error',
            message: 'An error occurred during login.',
            error: error.message
        });
    }
};

// Admin Logout
const logoutAdmin = (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).render('error', {
                title: 'Logout Error',
                message: 'Error logging out.'
            });
        }

        // Redirect to login page after successful logout
        res.render('admin/login', { layout: false });
    });
};


module.exports = {
    createAdmin,
    getAdmins,
    getAdminById,
    updateAdmin,
    deleteAdmin,
    loginAdmin,
    logoutAdmin
};
