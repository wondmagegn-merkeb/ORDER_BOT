const Order = require('../models/orderModel');
const {bot} = require('../bot/bot');

async function sendMessageToUser(telegramId, message) {
    try {
        if (!bot?.telegram?.sendMessage) {
            throw new Error("Bot is not fully initialized");
        }

        await bot.telegram.sendMessage(telegramId, message, {
            parse_mode: 'HTML'
        });
    } catch (err) {
        console.error('❌ Error sending Telegram message:', err.message);
      
    }
}




// ✅ Update an order
const updateOrder = async (req, res) => {
    try {
        const { id } = req.params;
        const { status, newTotalPrice } = req.body;

        const order = await Order.findByPk(id);
        if (!order) {
            return res.status(404).render('error', {
                title: 'Order Not Found',
                message: 'The requested order does not exist.'
            });
        }

        const oldStatus = order.status;

        // Update order
        await order.update({
            status,
            newTotalPrice
        });

        // Notify user if status changed
        if (oldStatus !== status) {
            let message = '';

            if (status === 'Cancelled') {
                message = `
<b>Your order has been <i>Cancelled</i>! ❌</b>

<i>We apologize for the inconvenience. If you have any questions, feel free to reach out.</i>
                `;
            } else if (status === 'In Progress') {
                if(order.totalPrice?.toFixed(2) == newTotalPrice?.toFixed(2)){

message = `
<b>Your order is now <i>In Progress</i>! 🔄</b>

<i>Total Price:</i> <b>${order.totalPrice?.toFixed(2) || 'N/A'}birr</b>


<i>Thank you for your patience! We are working hard to complete your order and will keep you updated.</i>
                `;

                }else{
                message = `
<b>Your order is now <i>In Progress</i>! 🔄</b>

<i>Old Price:</i> <b>${order.totalPrice?.toFixed(2) || 'N/A'}birr</b>
<i>New Price:</i> <b>${newTotalPrice?.toFixed(2) || 'N/A'}birr</b>

<i>Reason for Price Change:</i> <b>${order.special || 'Special Order Adjustment'}</b>

<i>Thank you for your patience! We are working hard to complete your order and will keep you updated.</i>
                `;}
            }

            // Send Telegram message
            if (message && order.telegramId) {
                await sendMessageToUser(order.telegramId, message);
            }
        }

        res.status(200).json({
            success: true,
            order
        });

    } catch (error) {
        console.error('Update Order Error:', error.message);
        res.status(500).render('error', {
            title: 'Server Error',
            message: 'Something went wrong while updating the order.',
            error: error.message
        });
    }
};

module.exports = {
    updateOrder,
sendMessageToUser,
};
