const Item = require("../models/itemModel");
const sharp = require("sharp");
const cloudinary = require("../../config/cloudinary");

// ✅ Create a new item
const createItem = async (req, res) => {
    try {
        const { name, description, price, availability } = req.body;
        let imageUrl = null;
        let publicId = null;

        if (req.file) {
            const optimizedImage = await sharp(req.file.buffer)
                .resize(800)
                .jpeg({ quality: 80 })
                .toBuffer();
console.log(req.file)
            const base64 = optimizedImage.toString("base64");
            const dataUri = `data:image/jpeg;base64,${base64}`;

            const result = await cloudinary.uploader.upload(dataUri, {
                folder: "items"
            });

            imageUrl = result.secure_url;
            publicId = result.public_id;
        }

        const newItem = await Item.create({
            name,
            description,
            price,
            availability,
            imageUrl,
            cloudinaryPublicId: publicId
        });

        const items = await Item.findAll();
        res.render("admin/items", {
            title: "Manage Items",
            items,
            message: "Item added successfully!"
        });

    } catch (error) {
        res.status(400).render("error", {
            title: "Error Creating Item",
            message: error.message
        });
    }
};

// ✅ Get all items
const getItems = async (req, res) => {
    try {
        const items = await Item.findAll();
        res.status(200).json({
            success: true,
            items
        });
    } catch (error) {
        res.status(400).render("error", {
            title: "Error Fetching Items",
            message: error.message
        });
    }
};

// ✅ Get a single item by ID
const getItemById = async (req, res) => {
    try {
        const { id } = req.params;
        const item = await Item.findByPk(id);

        if (!item) {
            return res.status(404).render("error", {
                title: "Item Not Found",
                message: "Item not found"
            });
        }

        res.status(200).json({
            success: true,
            item
        });
    } catch (error) {
        res.status(400).render("error", {
            title: "Error Fetching Item",
            message: error.message
        });
    }
};

// ✅ Update an item
const updateItem = async (req, res) => {
    try {
        const { id } = req.params;
        const { name, description, price, availability } = req.body;

        const item = await Item.findByPk(id);
        if (!item) {
            return res.status(404).render("error", {
                title: "Item Not Found",
                message: "Item not found"
            });
        }

        let imageUrl = item.imageUrl;
        let publicId = item.cloudinaryPublicId;

        if (req.file) {
            // Delete old image from Cloudinary
            if (item.cloudinaryPublicId) {
                await cloudinary.uploader.destroy(item.cloudinaryPublicId);
            }

            // Optimize and upload new image
            const optimizedImage = await sharp(req.file.buffer)
                .resize(800)
                .jpeg({ quality: 80 })
                .toBuffer();

            const base64 = optimizedImage.toString("base64");
            const dataUri = `data:image/jpeg;base64,${base64}`;

            const result = await cloudinary.uploader.upload(dataUri, {
                folder: "items"
            });

            imageUrl = result.secure_url;
            publicId = result.public_id;
        }

        await item.update({
            name,
            description,
            price,
            availability,
            imageUrl,
            cloudinaryPublicId: publicId
        });

        const items = await Item.findAll();
        res.render("admin/items", {
            title: "Manage Items",
            items,
            message: "Item updated successfully!"
        });

    } catch (error) {
        res.status(400).render("error", {
            title: "Error Updating Item",
            message: error.message
        });
    }
};

// ✅ Delete an item
const deleteItem = async (req, res) => {
    try {
        const { id } = req.params;

        const item = await Item.findByPk(id);
        if (!item) {
            return res.status(404).render("error", {
                title: "Item Not Found",
                message: "Item not found"
            });
        }

        // Delete from Cloudinary
        if (item.cloudinaryPublicId) {
            await cloudinary.uploader.destroy(item.cloudinaryPublicId);
        }

        await item.destroy();

        const items = await Item.findAll();
        res.render("admin/items", {
            title: "Manage Items",
            items
        });

    } catch (error) {
        res.status(400).render("error", {
            title: "Error Deleting Item",
            message: error.message
        });
    }
};

module.exports = {
    createItem,
    getItems,
    getItemById,
    updateItem,
    deleteItem
};
