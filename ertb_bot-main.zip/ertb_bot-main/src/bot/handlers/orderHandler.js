const Order = require('../../models/orderModel');
const Item = require('../../models/itemModel');
const { Markup } = require('telegraf');
const webpush = require('web-push');
const { Subscription } = require('../../models/subscriptionModel');
const botAdmin = require('../adminBot');
const path = require('path');
const fs = require('fs');

webpush.setVapidDetails(
    `mailto:${process.env.ADMIN_EMAIL}`,
    process.env.VAPID_PUBLIC_KEY,
    process.env.VAPID_PRIVATE_KEY
);

async function placeOrder(ctx, itemId) {
    const telegramId = ctx.from.id.toString();
    const item = await Item.findByPk(itemId);
    if (!item) return ctx.reply('Item not found.');

    const lastOrder = await Order.findOne({
        where: { telegramId },
        order: [['createdAt', 'DESC']]
    });

    if (!ctx.session) ctx.session = {};
    ctx.session.orderData = {
        itemId,
        item,
        telegramId,
        fullName: lastOrder?.fullName || null,
        phoneNumberOne: lastOrder?.phone1 || null,
        phoneNumber: lastOrder?.phone2 || null,
        
    };

    if (!ctx.session.orderData.fullName) {
        return ctx.reply('Please provide your full name:');
    }

    if (!ctx.session.orderData.phoneNumber) {
        return ctx.reply('Do you have a second phone number? If not, just type "No".');
    }

    if (!ctx.session.orderData.quantity) {
        return ctx.reply(`How many *${item.name}* would you like to order? `, { parse_mode: 'Markdown' });
    }
}

async function confirmOrder(ctx, itemId) {
    if (!ctx.session || !ctx.session.orderData) {
        return ctx.reply('No order found. Please start again.'+ctx.session.orderData.fullName);
    }

    console.log("confirm");

    const {
        item,
        telegramId,
        fullName,
        phoneNumberOne,
        phoneNumber,
        location,
        quantity,
        specialOrder
    } = ctx.session.orderData;

    const totalPrice = item.price * quantity;

    try {
        const order = await Order.create({
            telegramId,
            itemId: item.itemId,
            quantity,
            totalPrice,
            status: 'Pending',
            fullName,
            phone1: phoneNumberOne,
            phone2: phoneNumber,
            location,
            newTotalPrice: totalPrice,
            special: specialOrder
        });

        // 🔔 Push Notification
        const payload = JSON.stringify({
            title: 'Fikir and Astu',
            body: `<b>New Order Notification</b>\n\nA new order has been placed. Please review it.`
        });

        const subscriptions = await Subscription.findAll();
        subscriptions.forEach(sub => {
            webpush.sendNotification({
                endpoint: sub.endpoint,
                keys: sub.keys
            }, payload).catch(err => console.error('Push error:', err));
        });

        const adminCaption = `<b>📦 New Order!</b>\n🍕 <b>Food:</b> ${item.name}`;
        const isRemoteImage = item.imageUrl?.startsWith('http');

        if (isRemoteImage) {
            await botAdmin.telegram.sendPhoto(process.env.ADMIN_TELEGRAM_ID, item.imageUrl, {
                caption: adminCaption,
                parse_mode: 'HTML',
    reply_markup: {
        inline_keyboard: [
        
            [{ text: "📋 View Details", callback_data: `view_order_${order.orderId}` }]
        ]
    }
            });

            await botAdmin.telegram.sendPhoto(process.env.ADMIN_TELEGRAM_ID_1, item.imageUrl, {
                caption: adminCaption,
                parse_mode: 'HTML',
    reply_markup: {
        inline_keyboard: [
        
            [{ text: "📋 View Details", callback_data: `view_order_${order.orderId}` }]
        ]
    }
            });
            await botAdmin.telegram.sendPhoto("800439459", item.imageUrl, {
                caption: adminCaption,
                parse_mode: 'HTML',
    reply_markup: {
        inline_keyboard: [
        
            [{ text: "📋 View Details", callback_data: `view_order_${order.orderId}` }]
        ]
    }
            });
        } else {
            const localImagePath = path.resolve(__dirname, '../../../public', item.imageUrl || '');
            if (fs.existsSync(localImagePath)) {
                const photoStream = { source: fs.createReadStream(localImagePath) };

                await botAdmin.telegram.sendPhoto(process.env.ADMIN_TELEGRAM_ID, photoStream, {
                    caption: adminCaption,
                    parse_mode: 'HTML',
    reply_markup: {
        inline_keyboard: [
        
            [{ text: "📋 View Details", callback_data: `view_order_${order.orderId}` }]
        ]
    }
                });

                await botAdmin.telegram.sendPhoto(process.env.ADMIN_TELEGRAM_ID_1, photoStream, {
                    caption: adminCaption,
                    parse_mode: 'HTML',
    reply_markup: {
        inline_keyboard: [
        
            [{ text: "📋 View Details", callback_data: `view_order_${order.orderId}` }]
        ]
    }
                });
            } else {
                console.error('❌ Image file not found for admin:', localImagePath);
            }
        }

        const userCaption = `🎉 *Your order has been successfully placed!*\n\n` +
            `🧾 *Order Summary:*\n` +
            `👤 Full Name: ${fullName}\n` +
            `📱 Phone Number 1: ${phoneNumberOne}\n` +
            `📱 Phone Number 2: ${phoneNumber}\n` +
            `📍 Location: ${location}\n` +
            `🔢 Quantity: ${quantity}\n` +
            `📝 Special Note: ${specialOrder || 'None'}\n` +
            `💰 Total Price: ${totalPrice} birr\n\n` +
            `📦 We'll start processing your order shortly. Thank you! 🙏`;

        const keyboard = Markup.keyboard([
            ['start', 'view menu', 'last order status'],
            ['history'],
        ]).resize();

        // 👤 Send confirmation to user
        if (isRemoteImage) {
            await ctx.replyWithPhoto(item.imageUrl, {
                caption: userCaption,
                parse_mode: 'Markdown',
                ...keyboard
            });
        } else {
            const localImagePath = path.resolve(__dirname, '../../../public', item.imageUrl || '');
            if (fs.existsSync(localImagePath)) {
                await ctx.replyWithPhoto({ source: fs.createReadStream(localImagePath) }, {
                    caption: userCaption,
                    parse_mode: 'Markdown',
                    ...keyboard
                });
            } else {
                await ctx.reply(userCaption, {
                    parse_mode: 'Markdown',
                    ...keyboard
                });
            }
        }

        ctx.session.orderData = null;

    } catch (error) {
        console.error('❌ Error placing order:', error);
        ctx.reply('Something went wrong while placing your order. Please try again.'+error);
    }
}


async function getOrderHistory(ctx) {
    const telegramId = ctx.from.id.toString();

    try {
        const orders = await Order.findAll({
            where: { telegramId },
            include: [{ model: Item }],
            order: [['createdAt', 'DESC']]
        });

        if (!orders.length) {
            return ctx.reply('You have no previous orders.');
        }

        for (const [index, order] of orders.entries()) {
            const item = order.Item;
            const caption =
                `*#${index + 1} Order*\n` +
                `🍽️ *Item:* ${item?.name || 'Unknown'}\n` +
                `🔢 *Quantity:* ${order.quantity}\n` +
                `💰 *Total:* ${order.totalPrice} birr\n` +
                `📌 *Status:* ${order.status}\n` +
                `📅 *Date:* ${order.createdAt.toLocaleDateString()}`;

            if (item?.imageUrl?.startsWith('http')) {
                await ctx.replyWithPhoto(item.imageUrl, {
                    caption,
                    parse_mode: 'Markdown'
                });
            } else {
                await ctx.reply(caption, { parse_mode: 'Markdown' });
            }
        }

    } catch (error) {
        console.error('❌ Error fetching order history:', error);
        ctx.reply('Could not fetch your order history at the moment.');
    }
}

async function getLastOrderStatus(ctx) {
    const telegramId = ctx.from.id.toString();

    try {
        const lastOrder = await Order.findOne({
            where: { telegramId },
            order: [['createdAt', 'DESC']],
            include: [{ model: Item }]
        });

        if (!lastOrder) {
            return ctx.reply('You have not placed any orders yet.');
        }

        const item = lastOrder.Item;
        const caption =
            `🆕 *Latest Order Status*\n` +
            `🍽️ *Item:* ${item?.name || 'Unknown'}\n` +
            `🔢 *Quantity:* ${lastOrder.quantity}\n` +
            `💰 *Total:* ${lastOrder.totalPrice} birr\n` +
            `📌 *Status:* ${lastOrder.status}\n` +
            `📅 *Date:* ${lastOrder.createdAt.toLocaleDateString()}`;

        if (item?.imageUrl?.startsWith('http')) {
            await ctx.replyWithPhoto(item.imageUrl, {
                caption,
                parse_mode: 'Markdown'
            });
        } else {
            await ctx.reply(caption, { parse_mode: 'Markdown' });
        }

    } catch (error) {
        console.error('❌ Error fetching last order status:', error);
        ctx.reply('Could not fetch your last order status.');
    }
}

module.exports = {
    placeOrder,
    confirmOrder,
    getOrderHistory,
    getLastOrderStatus
};
