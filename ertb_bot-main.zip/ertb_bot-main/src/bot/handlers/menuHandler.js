const Item = require('../../models/itemModel');
const { Markup } = require('telegraf');
const path = require('path');
const fs = require('fs');

// Display the menu (list of available items with images)
async function getMenu(ctx) {
    try {
        const items = await Item.findAll();
        if (items.length === 0) {
            return ctx.reply('No items available currently.');
        }

        for (const item of items) {
            const itemDetails = `*Food Name:* ${item.name}\n*Price:* ${item.price} birr\n*Description:* ${item.description || 'No description available.'}`;

            // Check for image type
            if (item.imageUrl) {
                // External image
                if (item.imageUrl.startsWith('http')) {
                    await ctx.replyWithPhoto(item.imageUrl, {
                        caption: itemDetails,
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: "🛒 Order Now", callback_data: `order_now_${item.itemId}` }]
                            ]
                        }
                    });
                } else {
                    // Local image
                    const basePath = path.resolve(__dirname, '../../../public');
                    const imagePath = path.join(basePath, item.imageUrl);

                    if (fs.existsSync(imagePath)) {
                        await ctx.replyWithPhoto({ source: fs.createReadStream(imagePath) }, {
                            caption: itemDetails,
                            parse_mode: 'Markdown',
                            reply_markup: {
                                inline_keyboard: [
                                    [{ text: "🛒 Order Now", callback_data: `order_now_${item.itemId}` }]
                                ]
                            }
                        });
                    } else {
                        await ctx.reply(`Image not found for ${item.name}.\n${itemDetails}`, {
                            parse_mode: 'Markdown',
                            reply_markup: {
                                inline_keyboard: [
                                    [{ text: "🛒 Order Now", callback_data: `order_now_${item.itemId}` }]
                                ]
                            }
                        });
                    }
                }
            } else {
                // No image
                await ctx.reply(itemDetails, {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: "🛒 Order Now", callback_data: `order_now_${item.itemId}` }]
                        ]
                    }
                });
            }
        }
    } catch (error) {
        console.error('❌ Error displaying menu:', error);
        await ctx.reply('Something went wrong while fetching the menu.');
    }
}

module.exports = { getMenu };
