const Order = require('../../models/orderModel'); // Your Order model

// Check order status
async function checkOrderStatus(ctx) {
    try {
        const telegramId = ctx.from.id.toString();
        const orders = await Order.findAll({ where: { userId: telegramId } });

        if (orders.length === 0) {
            return ctx.reply('📦 You have no orders.');
        }

        let statusMessage = '📋 *Your Orders:*\n\n';
        orders.forEach(order => {
            statusMessage += `🆔 *Order ID:* ${order.orderId}\n📌 *Status:* ${order.status}\n\n`;
        });

        ctx.replyWithMarkdown(statusMessage);
    } catch (error) {
        console.error('Error checking order status:', error);
        ctx.reply('❌ An error occurred while checking your order status. Please try again later.');
    }
}

module.exports = { checkOrderStatus };
