const { Markup } = require('telegraf');
const {start}=require('./statusHandler')

async function handleFullName(ctx) {
    if (!ctx.session || !ctx.session.orderData) {
        return ctx.reply('Session expired. Please restart your order.');
    }

    const fullName = ctx.message.text;
    ctx.session.orderData.fullName = fullName;
    return ctx.reply('Please share your phone number:', Markup.keyboard([
        [Markup.button.contactRequest('📱 Share Phone Number')]
    ]).oneTime().resize());
    // Prompt for phone number
    
}

async function handlePhoneNumber(ctx) {
    if (!ctx.session || !ctx.session.orderData) {
        return ctx.reply('Session expired. Please restart your order.');
    }

    const input = ctx.message.text.trim(); // case-sensitive

    if (input.toLowerCase()=== 'no') {
        ctx.session.orderData.phoneNumber = 'No';
        return ctx.reply('Okay, we will proceed without a phone number. Now, how many of this item would you like to order?');
    }

    const phoneRegex = /^(09|07)\d{8}$/;
    if (!phoneRegex.test(input)) {
        
        return ctx.reply('❌ Invalid phone number. Please enter a 10-digit number starting with 09 or 07, or type "no" to skip.');
    }

    ctx.session.orderData.phoneNumber = input;
    return ctx.reply('✅ Phone number saved! Now, how many of this item would you like to order?');
}

async function handleQuantity(ctx) {
    if (!ctx.session || !ctx.session.orderData) {
        return ctx.reply('Session expired. Please restart your order.');
    }

    const quantity = parseInt(ctx.message.text, 10);
    
    if (isNaN(quantity) || quantity <= 0) {
        return ctx.reply('Please enter a valid quantity (a positive number).');
    }

    ctx.session.orderData.quantity = quantity;

    // Ask for any special instructions or customizations
    ctx.reply('If you have any special instructions (e.g., "Extra cheese", "No onions"), please type them now. Otherwise, type "No".');
}
async function handleSpecialOrder(ctx) {
    if (!ctx.session || !ctx.session.orderData) {
        return ctx.reply('Session expired. Please restart your order.');
    }

    const specialOrder = ctx.message.text.trim();

    if (specialOrder.toLowerCase() === 'no') {
        ctx.session.orderData.specialOrder = null;
    } else {
        ctx.session.orderData.specialOrder = specialOrder;
    }
 // Prompt for location
 return ctx.reply('Please share your location:', Markup.keyboard([
    [Markup.button.locationRequest('📍 Send Location')]
]).oneTime().resize());
   
}



async function handleLocation(ctx) {
    if (!ctx.session || !ctx.session.orderData) {
        return ctx.reply('Session expired. Please restart your order.');
    }

    // Ensure the user has sent location data
    if (!ctx.message.location) {
        return ctx.reply('Please send your location by clicking the 📍 button.');
    }

    const { latitude, longitude } = ctx.message.location;
    const locationString = `Lat: ${latitude}, Lng: ${longitude}`;

    // Save the location in the session
    ctx.session.orderData.location = locationString;

    // Log the data for debugging purposes
  

    // Fetching the order details from session
    const { item, fullName, phoneNumber, quantity, specialOrder } = ctx.session.orderData;

    // Calculate total price (item price * quantity)
    const totalPrice = item.price * quantity;

    // Show order summary to the user, including total price
  return ctx.reply(
  `Here’s your order summary\n\n` +
    `📦 Item: ${item.name} - ${item.price}birr x ${quantity} = ${totalPrice}birr\n` +
    `👤 Full Name: ${fullName}\n` +
    `📱 Phone Number One: ${ctx.session.orderData.phoneNumberOne}\n` +
    `📱 Phone Number Two: ${ctx.session.orderData.phoneNumber}\n` +
    `💬 Special Instructions: ${specialOrder || 'None'}\n\n` +
    `Do you want to proceed with the order?`,
  {
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [
        [{ text: "✅ Yes, Place Order", callback_data: `confirm_order_now_${item.itemId}` }],
        [{ text: "❌ No, Cancel", callback_data: `cancel_order_now_${item.itemId}` }],
       
      ]
    }
  }
);

}




async function cancelOrder(ctx) {
   await start(ctx,'Your order has been canceled.');
}

module.exports = { handleFullName, handlePhoneNumber, handleLocation, cancelOrder,handleQuantity,handleSpecialOrder };
