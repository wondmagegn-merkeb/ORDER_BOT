const { Markup } = require('telegraf');
const fs = require('fs');
const path = require('path');

const start = async (ctx, message) => {
    const basePath = path.resolve(__dirname, '../../../public');

    if (message.toLowerCase() === "menu") {
        const imagePath = path.join(basePath, 'welcome back.png');

        if (fs.existsSync(imagePath)) {
            await ctx.replyWithPhoto(
                { source: fs.createReadStream(imagePath) },
                {
                    caption:
                        `👋 *Welcome back!*\n\n` +
                        `📋 Use *menu* – to explore all available items\n` +
                        `🕘 Use *history* – to view your past orders\n\n` +
                        `👇 Choose an option below to get started.`,
                    parse_mode: 'Markdown',
                    ...Markup.keyboard([
                        ['start', 'view menu', 'last order status'],
                        ['history'],
                    ]).resize()
                }
            );
        } else {
            await ctx.reply("🚫 Welcome image not found.");
        }
    } else {
        await ctx.reply(
            message,
            {
                parse_mode: 'Markdown',
                ...Markup.keyboard([
                    ['start', 'view menu', 'last order status'],
                    ['history'],
                ]).resize()
            }
        );
    }
};

module.exports = { start };
