const { Telegraf, Markup } = require('telegraf');
const LocalSession = require('telegraf-session-local');
const path = require('path');
const fs = require('fs');

const User = require('../models/userModel');
const { getMenu } = require('./handlers/menuHandler');
const {
  placeOrder,
  confirmOrder,
  getOrderHistory,
  getLastOrderStatus
} = require('./handlers/orderHandler');

const {
  handleFullName,
  handlePhoneNumber,
  handleLocation,
  cancelOrder,
  handleQuantity,
  handleSpecialOrder
} = require('./handlers/userDetailsHandler');

const { checkOrderStatus } = require('./handlers/orderStatusHandler');
const { start } = require('./handlers/statusHandler');

const bot = new Telegraf(process.env.USER_BOT_TOKEN);

// Session support
bot.use(new LocalSession({ database: 'session_db.json' }).middleware());

// /start command
bot.start(async (ctx) => {
  const telegramId = ctx.from.id.toString();
  const username = ctx.from.username;
  const firstName = ctx.from.first_name || '';

  try {
    let user = await User.findOne({ where: { telegramId } });

    if (!user) {
      user = await User.create({ telegramId, username });
      const imagePath = path.resolve(__dirname, '../../public/welcome.png');
      await ctx.replyWithPhoto({ source: fs.createReadStream(imagePath) }, {
        caption: `👋 Welcome ${firstName} to our Telegram Order Bot! 🛒\n\n` +
          `📋 Use *menu* – to explore all available items\n` +
          `🕘 Use *history* – to view your past orders\n\n` +
          `👇 Choose an option below to get started.`,
        parse_mode: 'Markdown',
        ...Markup.keyboard([
          ['start', 'view menu', 'last order status'],
          ['history']
        ]).resize()
      });
    } else {
      start(ctx, 'menu');
    }
  } catch (err) {
    console.error('Error handling /start:', err);
    ctx.reply('Something went wrong. Please try again later.');
  }
});

// Handle callback queries
bot.on('callback_query', async (ctx) => {
  const data = ctx.callbackQuery.data;

  try {
    await ctx.answerCbQuery();

    if (data.startsWith('order_now_')) {
      const itemId = data.split('_')[2];
      return placeOrder(ctx, itemId);
    }

    if (data.startsWith('confirm_order_now_')) {
      const itemId = data.split('_')[3];
      return confirmOrder(ctx, itemId);
    }

    if (data.startsWith('cancel_order_now_')) {
      return cancelOrder(ctx);
    }

  } catch (err) {
    console.error('❌ Error handling callback:', err);
    ctx.reply('Something went wrong. Please try again.');
  }
});

// Commands and keywords
bot.hears('history', (ctx) => getOrderHistory(ctx));
bot.hears('last order status', (ctx) => getLastOrderStatus(ctx));
bot.hears('view menu', (ctx) => getMenu(ctx));
bot.hears('start', (ctx) => start(ctx, 'menu'));
bot.command('status', (ctx) => checkOrderStatus(ctx));

// Text input for order flow
bot.on('text', (ctx) => {
  if (!ctx.session.orderData) return;
  if (!ctx.session.orderData.fullName) return handleFullName(ctx);
  if (!ctx.session.orderData.phoneNumber) return handlePhoneNumber(ctx);
  if (!ctx.session.orderData.quantity) return handleQuantity(ctx);
  if (!ctx.session.orderData.specialOrder) return handleSpecialOrder(ctx);
});

// Location input
bot.on('location', (ctx) => {
  if (ctx.session.orderData && !ctx.session.orderData.location) {
    return handleLocation(ctx);
  }
});

// Contact input
bot.on('contact', (ctx) => {
  if (!ctx.session || !ctx.session.orderData) {
    return ctx.reply('Session expired. Please restart your order.');
  }

  const phoneNumberOne = ctx.message.contact.phone_number;
  ctx.session.orderData.phoneNumberOne = phoneNumberOne;

  return start(ctx, '✅ Got your phone number.\n\n📞 If you have a second contact number, please type it now.\nIf not, just type "No".');
});

// Export bot and launcher

// Function to send a message to a user by their telegramId
const sendMessageToUser = async (telegramId, message) => {
  try {
    await bot.telegram.sendMessage(telegramId, message);
    console.log(`Message sent to ${telegramId}`);
  } catch (err) {
    console.error(`Error sending message to ${telegramId}:`, err);
  }
};

// Export bot and sendMessageToUser function
module.exports = {
  bot,
  sendMessageToUser
};

 
 

