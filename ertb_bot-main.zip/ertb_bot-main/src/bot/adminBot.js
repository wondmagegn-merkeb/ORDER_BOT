const { Telegraf, Markup } = require('telegraf');
const path = require('path');
const fs = require('fs');

const { sendMessageToUser } = require('../controllers/orderController');
const { Order, Item, User } = require('../models/indexModel');

const botAdmin = new Telegraf(process.env.ADMIN_BOT_TOKEN);
// ===== Allowed admin IDs =====
const ADMIN_IDS = ['800439459',process.env.ADMIN_TELEGRAM_ID]; // Replace with real admin Telegram IDs

// ===== Admin authentication middleware =====
botAdmin.use((ctx, next) => {
    if (!ADMIN_IDS.includes(String(ctx.from.id))) {
        return ctx.reply('❌ You are not authorized to use this bot.');
    }
    return next();
});

const tempStates = {}; // Temporary in-memory state tracking

// ===== /start command with dashboard stats =====
botAdmin.start(async (ctx) => {
    const firstName = ctx.from.first_name || 'Admin';
    
// console.log(sendMessageToUser)
// console.log(bot)
    try {
        const imagePath = path.join(path.resolve(__dirname, '../../public'), 'welcome.png');
        await ctx.replyWithPhoto({ source: fs.createReadStream(imagePath) }, {
            caption:
                `👋 Hello *${firstName}*,\n\n` +
                `Welcome to the *Admin Dashboard* of our Telegram Order Bot! 🛠️\n\n` +
                `Here, you can:\n` +
                `📦 View, update, and manage all customer orders\n` +
                `📊 Monitor order statuses in real time\n\n` +
                `Use the menu or type a command to get started.\n\n` +
                `Thanks for managing our orders like a pro! 🚀`,
            parse_mode: 'Markdown',
            ...Markup.keyboard([
                ['start','orders in progress', 'orders in pending']
            ]).resize()
        });

        // Dashboard summary stats
        const initialMessage = `
<b>Your order has been <i>Cancelled</i>! ❌</b>

<i>We apologize for the inconvenience. If you have any questions, feel free to reach out.</i>
`;
await sendMessageToUser("800439459", initialMessage);
    } catch (err) {
        console.error('Error handling admin start:', err);
        await ctx.reply('Something went wrong. Please try again later.'+err);
    }
});
botAdmin.hears('start', async (ctx) => {
    try  {
    // Dashboard summary stats
    const totalOrders = await Order.count();
    const pendingOrders = await Order.count({ where: { status: 'pending' } });
    const inProgressOrders = await Order.count({ where: { status: 'In Progress' } });
    const completedOrders = await Order.count({ where: { status: 'Completed' } });
    const canceledOrders = await Order.count({ where: { status: 'Canceled' } }); // 👈 Added

    await ctx.reply(
        `📊 *Dashboard Overview:*\n\n` +
        `📝 *Total Orders:* \`${totalOrders}\`\n` +
        `⏳ *Pending:* \`${pendingOrders}\`\n` +
        `🔄 *In Progress:* \`${inProgressOrders}\`\n` +
        `✅ *Completed:* \`${completedOrders}\`\n` +
        `❌ *Canceled:* \`${canceledOrders}\``, // 👈 Display it here
        {
            parse_mode: 'Markdown',
            
        }
    );

        } catch (err) {
        console.error('❌ Error fetching pending orders:', err);
        await ctx.reply('Something went wrong while fetching your pending orders.\n' + err);
    }
});
// ===== List Pending Orders =====
botAdmin.hears('orders in pending', async (ctx) => {
    try {
        const orders = await Order.findAll({
            where: { status: 'pending' },
            include: [
                { model: User, attributes: ['username'] },
                { model: Item, attributes: ['name', 'price', 'imageUrl'] }
            ]
        });

        if (orders.length === 0) return ctx.reply('✅ No pending orders at the moment.');

        for (const order of orders) {
            const item = order.Item;
            const caption = `📝 *Order ID:* ${order.orderId}\n` +
                `🛍️ *Food:* ${item?.name}\n` +
                `💰 *Price:* ${order.totalPrice} birr\n`;
            const message = `
<b>Your order is now <i>In Progress</i>! 🔄</b>

<i>Total Price:</i> <b>${order.totalPrice?.toFixed(2) || 'N/A'} birr</b>

<i>Thank you for your patience! We are working hard to complete your order and will keep you updated.</i>
`;
            await sendMessageToUser(order.telegramId, message);
            await ctx.replyWithPhoto(item.imageUrl, {
                caption,
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([
                    [Markup.button.callback("📋 View Details", `view_order_${order.orderId}`)]
                ])
            });
        }
    } catch (err) {
        console.error('❌ Error fetching pending orders:', err);
        await ctx.reply('Something went wrong while fetching your pending orders.\n' + err);
    }
});

// ===== List In-Progress Orders =====
botAdmin.hears('orders in progress', async (ctx) => {
    try {
        const orders = await Order.findAll({
            where: { status: 'In Progress' },
            include: [
                { model: User, attributes: ['username'] },
                { model: Item, attributes: ['name', 'price', 'imageUrl'] }
            ]
        });

        if (orders.length === 0) return ctx.reply('✅ No orders currently in progress.');

        for (const order of orders) {
            const item = order.Item;
            let googleMapsLink = '📍 Location: Not Provided';
            const match = order.location?.match(/Lat:\s*(-?\d+\.\d+),\s*Lng:\s*(-?\d+\.\d+)/);
            if (match) {
                const [ , lat, lng ] = match;
                googleMapsLink = `[📍 View Map](https://maps.google.com/?q=${lat},${lng})`;
            }
            const caption =
                `📝 *Order ID:* ${order.orderId}\n` +
                `🧍 *Customer:* ${order.fullName}\n` +
                `👤 *Username:* @${order.User?.username || 'N/A'}\n` +
                `🛍️ *Item:* ${item?.name}\n` +
                `💵 *Item Price:* ${item?.price} birr\n` +
                `🔢 *Quantity:* ${order.quantity}\n` +
                `💰 *Price (old):* ${order.totalPrice} birr\n` +
                `💰 *Price (new):* ${order.newTotalPrice} birr\n` +
                `📞 *Phone 1:* ${order.phone1}\n` +
                `📞 *Phone 2:* ${order.phone2 || 'N/A'}\n` +
                `📝 *Special Note:* ${order.special || 'None'}\n` +
                `🚚 *Status:* In Progress\n\n` +
                `${googleMapsLink}`;

            await ctx.replyWithPhoto(item.imageUrl, {
                caption,
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([
                    [Markup.button.callback('✅ Mark Completed', `mark_completed_${order.orderId}`)]
                ])
            });
        }
    } catch (err) {
        console.error('❌ Error fetching in-progress orders:', err);
        await ctx.reply('Something went wrong while fetching in-progress orders.\n' + err);
    }
});

// ===== Callback Query Handler =====
botAdmin.on('callback_query', async (ctx) => {
    const data = ctx.callbackQuery.data;


    // ----- View Order Details -----
    if (data.startsWith('view_order_')) {
        const orderId = data.split('_')[2];
        await ctx.answerCbQuery();
        try {
            const order = await Order.findByPk(orderId, {
                include: [
                    { model: User, attributes: ['username'] },
                    { model: Item, attributes: ['name', 'price', 'description', 'imageUrl'] }
                ]
            });
            if (!order) return ctx.reply('Order not found.');

            const item = order.Item;
            let googleMapsLink = '📍 Location: Not Provided';
            const match = order.location?.match(/Lat:\s*(-?\d+\.\d+),\s*Lng:\s*(-?\d+\.\d+)/);
            if (match) {
                const [ , lat, lng ] = match;
                googleMapsLink = `[📍 View Map](https://maps.google.com/?q=${lat},${lng})`;
            }
            const caption =
                `📝 *Order ID:* ${order.orderId}\n` +
                `🧍 *Customer:* ${order.fullName}\n` +
                `👤 *Username:* @${order.User?.username || 'N/A'}\n` +
                `🛍️ *Item:* ${item?.name}\n` +
                `💵 *Item Price:* ${item?.price} birr\n` +
                `🔢 *Quantity:* ${order.quantity}\n` +
                `💰 *Price (old):* ${order.totalPrice} birr\n` +
                `💰 *Price (new):* ${order.newTotalPrice} birr\n` +
                `📞 *Phone 1:* ${order.phone1}\n` +
                `📞 *Phone 2:* ${order.phone2 || 'N/A'}\n` +
                `📝 *Special Note:* ${order.special || 'None'}\n` +
                `🚚 *Status:* In Pending\n\n` +
                `${googleMapsLink}`;

            await ctx.replyWithPhoto(item.imageUrl, {
                caption,
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([
                    [Markup.button.callback('🚚 Mark In Progress', `mark_inprogress_${order.orderId}`)],
                    [Markup.button.callback('❌ Cancel Order', `cancel_order_${order.orderId}`)]
                ])
            });
        } catch (err) {
            console.error('❌ Error viewing order:', err);
            await ctx.reply('Something went wrong while viewing order details.');
        }
    }

    // ----- Mark Order In Progress (ask for price edit) -----
    if (data.startsWith('mark_inprogress_')) {
        const orderId = data.split('_')[2];
        tempStates[ctx.from.id] = { action: 'confirm_edit_price', orderId };
        await ctx.answerCbQuery();
        return ctx.reply('📝 Do you want to edit the price before marking this order as *in progress*?', {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('✅ Yes', `edit_price_yes_${orderId}`)],
                [Markup.button.callback('❌ No', `edit_price_no_${orderId}`)]
            ])
        });
    }

    // ----- Admin Chooses to Edit Price -----
    if (data.startsWith('edit_price_yes_')) {
        const orderId = data.split('_')[3];
        tempStates[ctx.from.id] = { action: 'awaiting_price_input', orderId };
        await ctx.answerCbQuery();
        return ctx.reply('💰 Please send the *new price* for the order:', { parse_mode: 'Markdown' });
    }

    // ----- Admin Chooses Not to Edit Price -----
    if (data.startsWith('edit_price_no_')) {
        const orderId = data.split('_')[3];
        await ctx.answerCbQuery();
        try {
            const order = await Order.findByPk(orderId);
            if (!order) return ctx.reply('❌ Order not found.');
            order.status = 'In Progress';
            await order.save();

            const message = `
<b>Your order is now <i>In Progress</i>! 🔄</b>

<i>Total Price:</i> <b>${order.totalPrice?.toFixed(2) || 'N/A'} birr</b>

<i>Thank you for your patience!</i>
`;
            await sendMessageToUser(order.telegramId, message);
            return ctx.reply('🚚 Order marked as *In Progress* successfully!', { parse_mode: 'Markdown' });
        } catch (err) {
            console.error('❌ Error updating order:', err);
            return ctx.reply('Something went wrong while updating the order.');
        }
    }

    // ----- Mark Order as Completed -----
    if (data.startsWith('mark_completed_')) {
        const orderId = data.split('_')[2];
        await ctx.answerCbQuery();
        try {
            const order = await Order.findByPk(orderId);
            if (!order) return ctx.reply('❌ Order not found.');
            order.status = 'Completed';
            await order.save();
            return ctx.reply('✅ Order marked as *Completed* successfully!', { parse_mode: 'Markdown' });
        } catch (err) {
            console.error('❌ Error updating order status to completed:', err);
            return ctx.reply('Something went wrong while marking the order as completed.');
        }
    }

    // ----- Cancel Order: Ask for confirmation -----
    if (data.startsWith('cancel_order_')) {
        const orderId = data.split('_')[2];
        await ctx.answerCbQuery();
        return ctx.reply('❗ Are you sure you want to cancel this order?', {
            ...Markup.inlineKeyboard([
                [Markup.button.callback('❌ Yes, Cancel Order', `confirm_cancel_${orderId}`)],
                [Markup.button.callback('↩️ No, Go Back', 'cancel_back')]
            ])
        });
    }

    // ----- Confirm Cancellation -----
    if (data.startsWith('confirm_cancel_')) {
        const orderId = data.split('_')[2];
        try {
            const order = await Order.findByPk(orderId);
            if (!order) return ctx.reply('❌ Order not found.');
            order.status = 'Cancelled';
            await order.save();

            const message = `
<b>Your order has been <i>Cancelled</i>! ❌</b>

<i>We apologize for the inconvenience. If you have any questions, feel free to reach out.</i>
`;
            await sendMessageToUser(order.telegramId, message);

            return ctx.reply('✅ Order has been successfully cancelled.', { parse_mode: 'Markdown' });
        } catch (err) {
            console.error('❌ Error cancelling order:', err);
            return ctx.reply('Something went wrong while cancelling the order.');
        }
    }
});

// ===== Export the bot =====
module.exports = botAdmin;
