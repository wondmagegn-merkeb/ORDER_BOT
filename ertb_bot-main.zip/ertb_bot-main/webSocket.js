// websocket.js
const WebSocket = require('ws');

const wss = new WebSocket.Server({ port: 8080 });
const clients = [];

wss.on('connection', (ws) => {
    console.log('✅ A user connected to WebSocket');
    clients.push(ws);

    ws.send(JSON.stringify({ message: 'Welcome to the WebSocket server!' }));

    ws.on('close', () => {
        console.log('❌ A user disconnected');
        const index = clients.indexOf(ws);
        if (index !== -1) {
            clients.splice(index, 1);
        }
    });
});

// Function to send a notification to all connected clients
function sendOrderNotification(orderId, status, newTotalPrice) {
    const message = JSON.stringify({ orderId, status, newTotalPrice });
    clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            console.log("📤 Sending WebSocket Message:", message);
            client.send(message);
        }
    });
}

module.exports = { sendOrderNotification };
