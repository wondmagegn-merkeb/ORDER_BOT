require('dotenv').config(); // Load environment variables
const express = require('express');
const cors = require('cors');
const path = require('path');
const session = require('express-session');
const expressLayouts = require('express-ejs-layouts');
const { sequelize } = require('./config/db'); // Ensure db.js exists
const webpush = require('web-push');
const bodyParser = require('body-parser');
const { Subscription } = require('./src/models/subscriptionModel'); // Assuming Subscription is defined in models
const authMiddleware = require('./middleware/authMiddleware'); 
const {loginAdmin,logoutAdmin}=require('./src/controllers/adminController')
// Import Bot
const {bot} = require('./src/bot/bot');  // Import the bot from bot.js
const botAdmin = require('./src/bot/adminBot'); 
// Import Routes
const adminRoutes = require('./src/routes/adminRoutes');
const orderRoutes = require('./src/routes/orderRoutes');
const itemRoutes = require('./src/routes/itemRoutes');
const userRoutes = require('./src/routes/userRoutes');
const viewRoutes = require('./src/routes/viewRoutes');
      

const app = express();
const PORT = process.env.PORT || 8080;
// run this once to generate your keys

webpush.setVapidDetails(`mailto:${process.env.ADMIN_EMAIL}`, process.env.VAPID_PUBLIC_KEY, process.env.VAPID_PRIVATE_KEY);


// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.json());  // Body parser for subscription data

// Session Middleware
app.use(session({
    secret: process.env.JWT_SECRET || 'default_secret',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: process.env.NODE_ENV === 'production' } // Secure cookies in production
}));

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Set up EJS as the view engine
app.use(expressLayouts);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'src', 'views'));
app.set('layout', 'layouts/main'); // Ensure 'main.ejs' exists inside 'views/layouts'

app.get(['/', '/login'], (req, res) => {
    res.render('admin/login', { layout: false });
});
app.post('/api/admin/login', loginAdmin);
app.get('/api/admin/logout', logoutAdmin);
app.use('/api/admins',adminRoutes);
app.use('/api/orders', authMiddleware, orderRoutes);
app.use('/api/items', authMiddleware, itemRoutes);
app.use('/api/users', authMiddleware, userRoutes);
app.use('/admin',  viewRoutes); // View routes for admin panel

// Push Notification Routes
app.post('/subscribe', async (req, res) => {
    console.log(req.body)
    const { endpoint, expirationTime, keys } = req.body;
    try {
        await Subscription.findOrCreate({ where: { endpoint }, defaults: { expirationTime, keys } });
        res.status(201).json({ message: 'Subscription saved' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error saving subscription' });
    }
});



// Handle 404 pages
app.use((req, res) => {
    res.status(404).render('404', { layout: false });
});

bot.launch().then(() => {
    // Correct order

  console.log('Bot started');


}).catch((error) => {
    console.error('❌ Error launching bot:', error);
});
// Database Connection
sequelize.sync({ alter: true })
    .then(() => console.log('✅ Database connected and synchronized.'))
    .catch(error => console.error('❌ Database connection failed:', error));

// Start the Express server

// Start the bot **after** the server is running

botAdmin.launch().then(() => {
    console.log('🤖 Bot is running...');
}).catch((error) => {
    console.error('❌ Error launching bot:', error);
});
app.listen(PORT, () => { console.log('bot.telegram:', bot.telegram);

    console.log(`🚀 Server running on port ${PORT}`);
});
