document.addEventListener("DOMContentLoaded", function () {
    // Sidebar Toggle
    const sidebar = document.querySelector("aside");
    const toggleBtn = document.createElement("button");
    toggleBtn.innerText = "☰";
    toggleBtn.style.position = "absolute";
    toggleBtn.style.top = "10px";
    toggleBtn.style.left = "10px";
    toggleBtn.style.background = "transparent";
    toggleBtn.style.border = "none";
    toggleBtn.style.fontSize = "24px";
    toggleBtn.style.cursor = "pointer";

    toggleBtn.addEventListener("click", function () {
        sidebar.style.display = sidebar.style.display === "none" ? "block" : "none";
    });

    document.body.appendChild(toggleBtn);

    // Highlight Active Sidebar Link
    const currentPath = window.location.pathname;
    document.querySelectorAll("aside ul li a").forEach(link => {
        if (link.getAttribute("href") === currentPath) {
            link.style.background = "#007bff";
            link.style.fontWeight = "bold";
        }
    });
});