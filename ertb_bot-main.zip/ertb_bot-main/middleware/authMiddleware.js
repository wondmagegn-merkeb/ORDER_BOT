const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
    // Check if the token is stored in the session
    const token = req.session.token;

    if (!token) {
        // Redirect to the login page if token is not present
        return res.redirect('/');
    }

    // Verify the token
    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
        if (err) {
            // If token is invalid or expired, redirect to the login page
            return res.redirect('/');
        }

        // If token is valid, attach decoded data to request and proceed
        req.admin = decoded;  // store admin info in request
        next();
    });
};

module.exports = authMiddleware;
