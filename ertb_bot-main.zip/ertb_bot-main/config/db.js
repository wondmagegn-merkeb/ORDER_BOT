require('dotenv').config();
const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(
  process.env.MYSQL_ADDON_DB,
  process.env.MYSQL_ADDON_USER,
  process.env.MYSQL_ADDON_PASSWORD,
  {
    host: process.env.MYSQL_ADDON_HOST,
    dialect: 'mysql',
    port: 3306,
    dialectOptions: {
      ssl: {
        rejectUnauthorized: false
      }
    }
  }
);

// ✅ Export the sequelize instance

module.exports = { sequelize };

